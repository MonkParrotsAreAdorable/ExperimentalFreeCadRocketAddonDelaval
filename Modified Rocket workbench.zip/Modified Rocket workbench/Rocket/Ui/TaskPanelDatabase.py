# SPDX-License-Identifier: LGPL-2.1-or-later
# SPDX-File-Notice: Part of the Rocket addon.

################################################################################
#                                                                              #
#   © 2021 David Carter <dcarter@davidcarter.ca>                               #
#                                                                              #
#   This addon is free software: you can redistribute it and/or modify         #
#   it under the terms of the GNU Lesser General Public License as             #
#   published by the Free Software Foundation, either version 2.1              #
#   of the License, or (at your option) any later version.                     #
#                                                                              #
#   This addon is distributed in the hope that it will be useful,              #
#   but WITHOUT ANY WARRANTY; without even the implied warranty                #
#   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                    #
#   See the GNU Lesser General Public License for more details.                #
#                                                                              #
#   You should have received a copy of the GNU Lesser General Public           #
#   License along with this addon. If not, see https://www.gnu.org/licenses    #
#                                                                              #
################################################################################


"""Class for database lookups"""

__title__ = "FreeCAD Database Lookup"
__author__ = "David Carter"
__url__ = "https://www.davesrocketshop.com"


import FreeCAD
import Materials

translate = FreeCAD.Qt.translate

from PySide import QtGui
from PySide.QtCore import QObject, Signal
from PySide.QtWidgets import QDialog, QGridLayout

from Rocket.Parts.PartDatabase import PartDatabase
from Ui.DialogLookup import DialogLookup
from Ui.Widgets.WaitCursor import WaitCursor

from Rocket.Utilities import _err

class _databaseLookupDialog(QDialog):

    def __init__(self, lookup, parent=None):
        super().__init__(parent)

        self._database = PartDatabase(FreeCAD.getUserAppDataDir() + "Mod/Rocket/")

        # define our window
        self.setGeometry(250, 250, 400, 350)
        self.setWindowTitle(translate('Rocket', "Rocket Component Parameter"))

        self.manufacturerLabel = QtGui.QLabel(translate('Rocket', "Manufacturer"), self)

        self.manufacturerInput = QtGui.QLineEdit(self)
        self.manufacturerInput.setMinimumWidth(100)

        self.partNumberLabel = QtGui.QLabel(translate('Rocket', "Part number"), self)

        self.partNumberInput = QtGui.QLineEdit(self)
        self.partNumberInput.setMinimumWidth(100)

        self.descriptionLabel = QtGui.QLabel(translate('Rocket', "Description"), self)

        self.descriptionInput = QtGui.QLineEdit(self)
        self.descriptionInput.setMinimumWidth(100)

        self.materialLabel = QtGui.QLabel(translate('Rocket', "Material"), self)

        self.materialUuid = QtGui.QLineEdit(self)
        self.materialUuid.hide()

        self.materialInput = QtGui.QLineEdit(self)
        self.materialInput.setMinimumWidth(100)

        self.lookupButton = QtGui.QPushButton(translate('Rocket', "Lookup..."), self)

        layout = QGridLayout()

        n = 0
        layout.addWidget(self.manufacturerLabel, n, 0, 1, 2)
        layout.addWidget(self.manufacturerInput, n, 1)
        n += 1

        layout.addWidget(self.partNumberLabel, n, 0)
        layout.addWidget(self.partNumberInput, n, 1)
        n += 1

        layout.addWidget(self.descriptionLabel, n, 0)
        layout.addWidget(self.descriptionInput, n, 1)
        n += 1

        layout.addWidget(self.materialLabel, n, 0)
        layout.addWidget(self.materialInput, n, 1)
        n += 1

        layout.addWidget(self.materialUuid, n, 1)
        n += 1

        layout.addWidget(self.lookupButton, n, 1)
        n += 1

        self.setLayout(layout)

class TaskPanelDatabase(QObject):

    dbLoad = Signal()   # emitted when a database lookup has completed

    def __init__(self, obj, lookup, parent=None):
        super().__init__()

        self._obj = obj
        self._lookup = lookup # Default component type
        self._lookupResult = None
        self._lookupMatch = False
        self._form = _databaseLookupDialog(lookup, parent)

        self._form.setWindowIcon(QtGui.QIcon(FreeCAD.getUserAppDataDir() + "Mod/Rocket/Resources/icons/RocketWorkbench.svg"))

        self._form.manufacturerInput.textEdited.connect(self.onManufacturer)
        self._form.partNumberInput.textEdited.connect(self.onPartNumber)
        self._form.descriptionInput.textEdited.connect(self.onDescription)
        self._form.materialInput.textEdited.connect(self.onMaterial)

        self._form.lookupButton.clicked.connect(self.onLookup)

        self._materialManager = Materials.MaterialManager()

        self.update()

    def getForm(self):
        return self._form

    def getLookupResult(self):
        return self._lookupResult

    def getLookupMatch(self):
        return self._lookupMatch

    def transferTo(self):
        "Transfer from the dialog to the object"
        self._obj.Manufacturer = self._form.manufacturerInput.text()
        self._obj.PartNumber = self._form.partNumberInput.text()
        self._obj.Description = self._form.descriptionInput.text()
        # self._obj.Material = self._form.materialInput.text()

        try:
            self._obj.ShapeMaterial = self._materialManager.getMaterial(self._form.materialUuid.text())
        except Exception:
            _err(translate("Rocket", "Material '{}' not found - using default material").format(self._form.materialUuid.text()))

    def transferFrom(self):
        "Transfer from the object to the dialog"
        self._form.manufacturerInput.setText(self._obj.Manufacturer)
        self._form.partNumberInput.setText(self._obj.PartNumber)
        self._form.descriptionInput.setText(self._obj.Description)

        material = self._obj.ShapeMaterial
        self._form.materialInput.setText(material.Name)
        self._form.materialUuid.setText(material.UUID)

    def onManufacturer(self, value):
        self._obj.Manufacturer = value

    def onPartNumber(self, value):
        self._obj.PartNumber = value

    def onDescription(self, value):
        self._obj.Description = value

    def onMaterial(self, value):
        self._obj.Material = value

    def _lookupUpdate(self, result):
        self._obj.Manufacturer = result["manufacturer"]
        self._obj.PartNumber = result["part_number"]
        self._obj.Description = result["description"]

        try:
            self._obj.ShapeMaterial = self._materialManager.getMaterial(result["uuid"])
        except Exception:
            _err(translate("Rocket", "Material '{}' not found - using default material").format(result["uuid"]))

        self.transferFrom()

        self.dbLoad.emit()

    def onLookup(self):
        form = DialogLookup(self._lookup, self._obj)
        form.exec()

        with WaitCursor():
            if len(form.result) > 0:
                self._lookupResult = form.result
                self._lookupMatch = form.match
                self._lookupUpdate(form.result)

    def update(self):
        'fills the widgets'
        self.transferFrom()
