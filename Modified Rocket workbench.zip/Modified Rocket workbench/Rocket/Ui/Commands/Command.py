# SPDX-License-Identifier: LGPL-2.1-or-later
# SPDX-File-Notice: Part of the Rocket addon.

################################################################################
#                                                                              #
#   © 2021 David Carter <dcarter@davidcarter.ca>                               #
#                                                                              #
#   This addon is free software: you can redistribute it and/or modify         #
#   it under the terms of the GNU Lesser General Public License as             #
#   published by the Free Software Foundation, either version 2.1              #
#   of the License, or (at your option) any later version.                     #
#                                                                              #
#   This addon is distributed in the hope that it will be useful,              #
#   but WITHOUT ANY WARRANTY; without even the implied warranty                #
#   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                    #
#   See the GNU Lesser General Public License for more details.                #
#                                                                              #
#   You should have received a copy of the GNU Lesser General Public           #
#   License along with this addon. If not, see https://www.gnu.org/licenses    #
#                                                                              #
################################################################################


"""Base class for commands"""

__title__ = "FreeCAD Commands"
__author__ = "David Carter"
__url__ = "https://www.davesrocketshop.com"

import FreeCAD
import FreeCADGui

from Rocket.Constants import FEATURE_ROCKET
from Rocket.RocketComponent import RocketComponent
from Rocket.FeatureRocket import FeatureRocket

def getRocket() -> FeatureRocket | None:
    for obj in FreeCAD.ActiveDocument.Objects:
        if hasattr(obj, "Proxy"):
            if hasattr(obj.Proxy, "getType"):
                if obj.Proxy.getType() == FEATURE_ROCKET:
                    return obj.Proxy

    return None

class Command:

    def partFeatureSelected(self) -> bool:
        """
            True if the selected object is a workbench feature
        """
        if FreeCADGui.ActiveDocument is None:
            return False
        sel = FreeCADGui.Selection.getSelection()
        if len(sel) == 1 and (sel[0].isDerivedFrom("Part::FeaturePython") or sel[0].isDerivedFrom("App::GeometryPython")):
            return True
        else:
            return False

    def partMoveableFeatureSelected(self) -> bool:
        """
            True if the selected object is a workbench feature, and can be moved in the tree
        """
        if FreeCADGui.ActiveDocument is None:
            return False
        sel = FreeCADGui.Selection.getSelection()
        if len(sel) == 1:
            if sel[0].isDerivedFrom("Part::FeaturePython"):
                if sel[0].Proxy.hasParent():
                    return True
            if sel[0].isDerivedFrom("App::GeometryPython"):
                return sel[0].Proxy.Type != FEATURE_ROCKET

        return False

    def partFinSelected(self) -> bool:
        """
            True if the selected object has fins (Fin, FinCan)
        """
        if FreeCADGui.ActiveDocument:
            sel = FreeCADGui.Selection.getSelection()
            if len(sel) == 1 and sel[0].isDerivedFrom("Part::FeaturePython"):
                if hasattr(sel[0],"FinType"):
                    return True
        return False

    def partHasShape(self, part) -> bool:
        if part is None:
            return False
        for child in part.getChildren():
            if isinstance(child.Proxy,RocketComponent):
                return True
            if self.partHasShape(child.Proxy):
                return True
        return False

    def partRocketSelected(self) -> bool:
        """
            Checks to see if the selected part is part of a rocket
        """
        if FreeCADGui.ActiveDocument is None:
            return False
        sel = FreeCADGui.Selection.getSelection()
        if len(sel) == 1 and (sel[0].isDerivedFrom("Part::FeaturePython") or sel[0].isDerivedFrom("App::GeometryPython")):
            if hasattr(sel[0],"Proxy") and hasattr(sel[0].Proxy,"getRocket"):
                # Ensure the rocket has a rocket part
                rocket = sel[0].Proxy.getRocket()
                return self.partHasShape(rocket)
        return False

    def partStageEligibleFeature(self, feature) -> bool:
        """
            Checks to see if we're at a point where we can add a stage. Stages can't be a standalone feature
        """
        if FreeCADGui.ActiveDocument:
            sel = FreeCADGui.Selection.getSelection()
            if len(sel) == 1 and (sel[0].isDerivedFrom("Part::FeaturePython") or sel[0].isDerivedFrom("App::GeometryPython")):
                if isinstance(feature, list):
                    for f in feature:
                        if sel[0].Proxy.eligibleChild(f):
                            return True
                elif sel[0].Proxy.eligibleChild(feature):
                    return True
        return False

    def partEligibleFeature(self, feature) -> bool:
        """
            Checks to see if we can add a part. If a rocket or one of its parts is selected, then we check to see if the
            part can be added to the current feature. Outside of a rocket, parts can be added as standalone objects.
        """
        if FreeCADGui.ActiveDocument:
            if getRocket() is None:
                return True
            sel = FreeCADGui.Selection.getSelection()
            if len(sel) == 1 and (sel[0].isDerivedFrom("Part::FeaturePython") or sel[0].isDerivedFrom("App::GeometryPython")):
                if isinstance(feature, list):
                    for f in feature:
                        if sel[0].Proxy.eligibleChild(f):
                            return True
                elif sel[0].Proxy.eligibleChild(feature):
                    return True
                return False
        return True

    def noRocketBuilder(self) -> bool:
        if FreeCADGui.ActiveDocument is None:
            return False

        if getRocket() is None:
            return True
        
        return False
