# SPDX-License-Identifier: LGPL-2.1-or-later
# SPDX-File-Notice: Part of the Rocket addon.

################################################################################
#                                                                              #
#   © 2021 David Carter <dcarter@davidcarter.ca>                               #
#                                                                              #
#   This addon is free software: you can redistribute it and/or modify         #
#   it under the terms of the GNU Lesser General Public License as             #
#   published by the Free Software Foundation, either version 2.1              #
#   of the License, or (at your option) any later version.                     #
#                                                                              #
#   This addon is distributed in the hope that it will be useful,              #
#   but WITHOUT ANY WARRANTY; without even the implied warranty                #
#   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                    #
#   See the GNU Lesser General Public License for more details.                #
#                                                                              #
#   You should have received a copy of the GNU Lesser General Public           #
#   License along with this addon. If not, see https://www.gnu.org/licenses    #
#                                                                              #
################################################################################


"""Class for drawing fins"""

__title__ = "FreeCAD Fins"
__author__ = "David Carter"
__url__ = "https://www.davesrocketshop.com"

from typing import Any
import math

import FreeCAD
import Part
from Part import Shape, Wire, BSplineCurve, Vertex

from Rocket.Constants import FIN_CROSS_SQUARE, FIN_CROSS_ROUND, FIN_CROSS_AIRFOIL, FIN_CROSS_WEDGE, \
    FIN_CROSS_DIAMOND, FIN_CROSS_TAPER_LETE, FIN_CROSS_BICONVEX, FIN_CROSS_ELLIPSE

from Rocket.ShapeHandlers.FinShapeHandler import FinShapeHandler

CROSS_SECTIONS = 100  # Number of cross sections for the ellipse

class FinEllipseShapeHandler(FinShapeHandler):

    def __init__(self, obj : Any) -> None:
        super().__init__(obj)

    def _radiusAt(self, chord : float, height : float, x : float) -> float:
        major = height
        minor = chord / 2.0
        y = (minor / major) * math.sqrt(major * major - x * x)
        return y

    def _halfEllipseCurve(self, major : float, minor : float, thickness : float, midChord : float) -> Wire:
        if major > minor:
            ellipse = Part.Ellipse(FreeCAD.Vector(midChord, thickness, major),
                    FreeCAD.Vector(midChord - minor, thickness, 0),
                    FreeCAD.Vector(midChord, thickness, 0))
            arc = Part.ArcOfEllipse(ellipse, -math.pi/2, math.pi/2)
        else:
            ellipse = Part.Ellipse(FreeCAD.Vector(midChord - minor, thickness, 0),
                    FreeCAD.Vector(midChord, thickness, major),
                    FreeCAD.Vector(midChord, thickness, 0))
            arc =  Part.ArcOfEllipse(ellipse, 0, math.pi)

        return arc

    def _halfEllipse(self, major : float, minor : float, thickness : float, midChord : float) -> Wire:
        arc = self._halfEllipseCurve(major, minor, thickness, midChord)

        line = Part.makeLine((midChord + minor, thickness, 0), (midChord - minor, thickness, 0))
        wire = Part.Wire([arc.toShape(), line])
        return wire

    def _taperedEllipse(self) -> list:
        # The loft is 3 (or 4) ellipses, center and both sides
        min = self.minimumEdge() / 2
        height = self._height
        center1 = self._halfEllipse(height, self._midChord, min, self._midChord)
        center2 = self._halfEllipse(height, self._midChord, -min, self._midChord)

        halfThickness = self._rootThickness / 2.0
        if self._rootPerCent:
            length = self._rootChord * (self._rootLength1 / 100.0)
        else:
            length = self._rootLength1
        radius = self._midChord - length
        height = self._height - length
        side1 = self._halfEllipse(height, radius, -halfThickness, self._midChord)
        side2 = self._halfEllipse(height, radius,  halfThickness, self._midChord)

        if min > 0:
            return [[side1, center2], [center2, center1], [center1, side2]]
        return [[side1, center1], [center1, side2]]

    def _squareEllipse(self) -> list:
        # The loft is 2 ellipses - both sides
        height = self._height
        halfThickness = self._rootThickness / 2.0

        side1 = self._halfEllipse(height, self._midChord, -halfThickness, self._midChord)
        side2 = self._halfEllipse(height, self._midChord,  halfThickness, self._midChord)

        return [side1, side2]

    def _makeCut(self) -> None:
        # # The loft is 3 ellipses, center and both sides
        # if self._rootCrossSection == FIN_CROSS_ROUND:
        #     halfThickness = self._rootThickness / 2.0
        #     height = self._height - halfThickness

        #     path = self._halfEllipseCurve(height, self._midChord - halfThickness,  0.0, self._midChord)

        #     arc = Part.Arc(FreeCAD.Vector(0, -halfThickness, 0), FreeCAD.Vector(-halfThickness, 0, 0), FreeCAD.Vector(0, halfThickness, 0))
        #     line = Part.LineSegment(FreeCAD.Vector(0, -halfThickness, 0), FreeCAD.Vector(0, halfThickness, 0))
        #     # wire = Part.Wire([arc.toShape(), line])
        #     # face = Part.Face(wire)
        #     shape = Part.Shape([arc, line])
        #     Part.show(shape)
        #     Part.show(path.toShape())

        #     # print(dir(wire))

        #     part = Part.makeSweepSurface(path.toShape(), arc.toShape())
        #     return part

        #     # Create a semi-circle and sweep it along the path

        #     # return path.toShape()
        #     # makeSweep(const TopoDS_Shape& profile, double, int) const;

        return None

    def _makeAtHeightProfile(self, crossSection : str, height : float = 0.0, offset : float = 0.0) -> Wire:
        l1, l2 = self._lengthsFromPercent(self._rootChord, self._rootPerCent,
                                        self._rootLength1, self._rootLength2)
        if height < 0:
            radius = self._radiusAt(self._rootChord, self._height, 0.0)
        else:
            radius = self._radiusAt(self._rootChord, self._height, height)
        radius += 2.0 * offset
        tapered = self._rootCrossSection in [FIN_CROSS_ROUND, FIN_CROSS_BICONVEX, FIN_CROSS_ELLIPSE, FIN_CROSS_AIRFOIL, FIN_CROSS_WEDGE, FIN_CROSS_DIAMOND]
        if tapered:
            if height < 0:
                thickness = 2.0 * self._radiusAt(self._rootThickness / 2.0, self._height, 0.0)
            else:
                thickness = 2.0 * self._radiusAt(self._rootThickness / 2.0, self._height, height)
        else:
            thickness = self._rootThickness
        thickness += 2.0 * offset
        profile = self._makeChordProfile(crossSection,
            self._midChord - radius,
            radius * 2.0,
            thickness,
            height,
            l1,
            l2,
            midChordLimit = True
        )
        return profile

    def _makeRootProfile(self, height : float = 0.0) -> Wire:
        return self._makeAtHeightProfile(self._rootCrossSection, height)

    def _makeProfiles(self) -> list:
        if self._rootCrossSection == FIN_CROSS_TAPER_LETE:
            return self._taperedEllipse()
        if self._rootCrossSection in [FIN_CROSS_SQUARE]:
            return self._squareEllipse()

        min = self.minimumEdge()
        ellipses = []
        tapered = self._rootCrossSection in [FIN_CROSS_ROUND, FIN_CROSS_BICONVEX, FIN_CROSS_ELLIPSE, FIN_CROSS_AIRFOIL, FIN_CROSS_WEDGE, FIN_CROSS_DIAMOND]

        l1, l2 = self._lengthsFromPercent(self._rootChord, self._rootPerCent,
                                        self._rootLength1, self._rootLength2)
        for i in range(CROSS_SECTIONS):
            height = i * self._height / float(CROSS_SECTIONS)
            radius = self._radiusAt(self._rootChord, self._height, height)
            if tapered:
                thickness = 2.0 * self._radiusAt(self._rootThickness / 2.0, self._height, height)
            else:
                thickness = self._rootThickness
            if thickness < min:
                thickness = min
            ellipses.append(self._makeChordProfile(self._rootCrossSection,
                self._midChord - radius,
                radius * 2.0,
                thickness, #self._rootThickness, # need to fix this
                height,
                l1,
                l2,
                midChordLimit = True
            ))

        # The tip is a special case
        if min > 0:
            radius = min
        else:
            radius = 1e-4 # Really small radius
        if tapered:
            thickness = radius
        else:
            thickness = self._rootThickness
            if thickness < min:
                thickness = min
        ellipses.append(self._makeChordProfile(self._rootCrossSection,
            self._midChord - radius,
            radius * 2.0,
            thickness, # need to fix this
            self._height,
            l1,
            l2,
            midChordLimit = True
        ))
        return ellipses
