# SPDX-License-Identifier: LGPL-2.1-or-later
# SPDX-File-Notice: Part of the Rocket addon.

################################################################################
#                                                                              #
#   © 2021 David Carter <dcarter@davidcarter.ca>                               #
#                                                                              #
#   This addon is free software: you can redistribute it and/or modify         #
#   it under the terms of the GNU Lesser General Public License as             #
#   published by the Free Software Foundation, either version 2.1              #
#   of the License, or (at your option) any later version.                     #
#                                                                              #
#   This addon is distributed in the hope that it will be useful,              #
#   but WITHOUT ANY WARRANTY; without even the implied warranty                #
#   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                    #
#   See the GNU Lesser General Public License for more details.                #
#                                                                              #
#   You should have received a copy of the GNU Lesser General Public           #
#   License along with this addon. If not, see https://www.gnu.org/licenses    #
#                                                                              #
################################################################################


"""Class for drawing bulkheads"""

__title__ = "FreeCAD Bulkhead Handler"
__author__ = "David Carter"
__url__ = "https://www.davesrocketshop.com"

from typing import Any

import FreeCAD
import Part
import math

from Rocket.Utilities import validationError, _err

translate = FreeCAD.Qt.translate

class BulkheadShapeHandler():
    def __init__(self, obj : Any) -> None:

        # This gets changed when redrawn so it's very important to save a copy
        self._placement = FreeCAD.Placement(obj.Placement)

        self._instanceCount = int(obj.InstanceCount)
        self._separation = float(obj.InstanceSeparation)

        self._diameter = float(obj.Diameter)
        self._thickness = float(obj.Thickness)
        self._step = bool(obj.Step)
        self._stepReverse = bool(obj.StepReverse)
        self._stepDiameter = float(obj.StepDiameter)
        self._stepThickness = float(obj.StepThickness)
        self._holes = bool(obj.Holes)
        self._holeDiameter = float(obj.HoleDiameter)
        self._holeCenter = float(obj.HoleCenter)
        self._holeCount = int(obj.HoleCount)
        self._holeOffset = float(obj.HoleOffset)

        self._obj = obj
        
        # Apply scaling
        self._scale = 1.0
        if obj.Proxy.isScaled():
            self._scale = 1.0 / obj.Proxy.getScale()

    def isValidShape(self) -> bool:
        # Perform some general validations
        if self._diameter <= 0:
            validationError(translate('Rocket', "Outer diameter must be greater than zero"))
            return False

        if self._step:
            if self._stepDiameter <= 0:
                validationError(translate('Rocket', "Step diameter must be greater than zero"))
                return False
            if self._stepDiameter >= self._diameter:
                validationError(translate('Rocket', "Step diameter must less than the outer diameter"))
                return False

        if self._holes:
            if self._holeDiameter <= 0:
                validationError(translate('Rocket', "Hole diameter must be greater than zero"))
                return False
            if self._holeCenter + (self._holeDiameter / 2.0) >= (self._diameter / 2.0):
                validationError(translate('Rocket', "Hole extends outside the outer diameter"))
                return False
            if self._step:
                if self._holeCenter + (self._holeDiameter / 2.0) >= (self._stepDiameter / 2.0):
                    validationError(translate('Rocket', "Hole extends outside the step diameter"))
                    return False

        return True

    def _drawBulkhead(self) -> Any:
        bulkhead = Part.makeCylinder(self._diameter / 2.0, self._thickness, FreeCAD.Vector(0,0,0), FreeCAD.Vector(1,0,0))
        if self._step:
            if self._stepReverse:
                step = Part.makeCylinder(self._stepDiameter / 2.0, self._stepThickness, FreeCAD.Vector(self._thickness,0,0), FreeCAD.Vector(1,0,0))
            else:
                step = Part.makeCylinder(self._stepDiameter / 2.0, self._stepThickness, FreeCAD.Vector(-self._thickness,0,0), FreeCAD.Vector(1,0,0))
            bulkhead = bulkhead.fuse(step)

        # Add any holes
        if self._holes:
            thickness = self._thickness
            if self._step:
                thickness += self._stepDiameter
            for i in range(0, self._holeCount):
                hole = Part.makeCylinder(self._holeDiameter / 2.0, thickness, FreeCAD.Vector(0,self._holeCenter,0), FreeCAD.Vector(1,0,0))

                # Rotate around the centerline
                aTrsf=FreeCAD.Matrix()
                aTrsf.rotateX(((i * 2.0 *math.pi) / self._holeCount) + math.radians(self._holeOffset) + math.pi/2.0)
                hole.transformShape(aTrsf)
                bulkhead = bulkhead.cut(hole)

        return bulkhead

    def drawInstances(self) -> Any:
        bulkheads = []
        base = self._drawBulkhead()
        for i in range(self._instanceCount):
            bulkhead = Part.Shape(base) # Create a copy
            bulkhead.translate(FreeCAD.Vector(i * (self._thickness + self._separation),0,0))
            bulkheads.append(bulkhead)

        return Part.makeCompound(bulkheads)

    def draw(self) -> None:
        if not self.isValidShape():
            return

        try:
            self._obj.Shape = self.drawInstances()
            self._obj.Placement = self._placement
        except (ZeroDivisionError, Part.OCCError):
            _err(translate('Rocket', "Bulkhead parameters produce an invalid shape"))
            return
